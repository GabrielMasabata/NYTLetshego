//
//  Constants.swift
//  NYTimes
//
//  Created by Gabriel Masabata on 9/13/21.
//  Copyright © 2021 Gabriel Masabata. All rights reserved.
//
import UIKit
import SwiftyUserDefaults

struct  Notifications {
  static let  appStarted      = "kAppStartedNotification";
}

extension DefaultsKeys {
  static let kAppLaunched     = DefaultsKey<Bool>("kAppLaunched")
}


func ApplicationDelegate() -> AppDelegate{
  return UIApplication.shared.delegate as! AppDelegate
}
