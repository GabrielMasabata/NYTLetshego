//
//  NYBaseService.swift
//  NYTimes
//
//  Created by Gabriel Masabata on 9/13/21.
//  Copyright © 2021 Gabriel Masabata. All rights reserved.
//


import UIKit
import Alamofire

protocol NYBaseServiceProtocol {
  func startService(parameters: [String: Any]?, completion: NetworkResultClosure)
}

class NYBaseService: NSObject {
}
