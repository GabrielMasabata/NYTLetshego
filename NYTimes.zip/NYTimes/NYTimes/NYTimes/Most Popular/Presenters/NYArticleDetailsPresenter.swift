//
//  NYArticleDetailsPresenter.swift
//  NYTimes
//
//  Created by Gabriel Masabata on 9/13/21.
//  Copyright © 2021 Gabriel Masabata. All rights reserved.
//

import UIKit

protocol NYArticleDetailsView: NYBaseView {
  func passedDetails()
  func changeActivityIndicator(state visisble: Bool)
}

protocol NYArticleDetailsActions: NYBasePresenter {
  associatedtype T = NYArticleDetailsView
  func onViewDidLoaded()
  func onStartLoadingImage()
  func onStopLoadingImage()
}

class NYArticleDetailsPresenter: NYArticleDetailsActions {
 weak var view: NYArticleDetailsView?
  
  func onViewDidLoaded() {
    view?.passedDetails()
  }
  
  func onStartLoadingImage() {
    view?.changeActivityIndicator(state: true)
  }
  
  func onStopLoadingImage() {
    view?.changeActivityIndicator(state: false)
  }
}
