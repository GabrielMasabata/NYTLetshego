//
//  NYNetworkClient.swift
//  NYTimes
//
//  Created by Gabriel Masabata on 9/13/21.
//  Copyright © 2021 Gabriel Masabata. All rights reserved.
//

import ObjectMapper
import Alamofire

typealias NetworkResultClosure = (NYBaseModel?, NYError?) -> Void

class NYNetworkClient: NSObject {
  
  static var client: Alamofire.SessionManager =  {
    
    let serverTrustPolicies: [String: ServerTrustPolicy] = [:]
    let configuration = URLSessionConfiguration.default
    let man = Alamofire.SessionManager(
      configuration: configuration,
      serverTrustPolicyManager: ServerTrustPolicyManager(policies: serverTrustPolicies)
    )
    return man
  }()
  
  
  class func startRequest<T: NYBaseModel>(requestConfiguration: NYNetworkRequest,
                                          withMappingClass objectClass: T?,
                                          completion completionClousure: NetworkResultClosure?) -> Void {
    client.request(requestConfiguration.completeURL.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)!,
                   method: requestConfiguration.requestMethod,
                   parameters: requestConfiguration.parameters,
                   encoding: requestConfiguration.encoding,
                   headers: requestConfiguration.headers).responseJSON{ (response: DataResponse<Any>) in
                    switch response.result {
                    case .success(_):
                      if let data = response.result.value {
                        print(data)
                        let model: NYBaseModel = Mapper<T>().map(JSONObject: data, toObject: objectClass!)
                        completionClousure!(model,nil)
                      }
                      break
                    case .failure(_):
                        completionClousure!(nil, NYError(response.result.error))
                      break
                    }
    }
  }
}
