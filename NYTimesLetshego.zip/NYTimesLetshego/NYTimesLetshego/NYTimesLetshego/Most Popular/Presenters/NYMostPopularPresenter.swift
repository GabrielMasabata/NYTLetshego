//
//  NYMostPopularPresenter.swift
//  NYTimesLetshego
//
//  Created by Gabriel Masabata on 9/13/21.
//  Copyright © 2021 Gabriel Masabata. All rights reserved.
//

import UIKit

protocol NYMostPopularView: NYBaseView {
  func showDetailsScreen(_ report: NYArticle)
  func showNews(_ news: [NYArticle])
}

protocol NYMostPopularActions: NYBasePresenter {
  associatedtype T = NYMostPopularView
  func onViewDidLoaded()
  func onViewDidRequestDetails(_ report: NYArticle)
}

class NYMostPopularPresenter: NYMostPopularActions {
  weak var view: NYMostPopularView?

  var filtered: [NYArticle] = [] {
    didSet{
      if filtered.isEmpty {
        view?.showNews(self.news.articles)
      } else {
        view?.showNews(filtered)
      }
    }
  }
  
  var news = NYNews() {
    didSet{
      view?.showNews(self.news.articles)
    }
  }
  
  let service = NYMostPopularServices()

  func onViewDidLoaded() {
    view?.showHud()
    service.startService(parameters: nil) {[weak self] (News, Error) in
      self?.view?.hideHud()
      if let _Error = Error {
        self?.view?.show(messageAlert: _Error.error.localizedDescription,
                         message: nil,
                         actionTitle: nil,
                         action: nil)
      }
      if let _news = (News as? NYNews) {
        _news.articles.forEach { $0.saveToRealm() }
        self?.news = _news
      } else {
        let _news = NYNews()
        _news.articles = NYArticle.storedObjects() as! [NYArticle]
        self?.news = _news
      }
    }
  }
  
  
  func onViewDidRequestDetails(_ report: NYArticle) {
    view?.showDetailsScreen(report)
  }
  
}
