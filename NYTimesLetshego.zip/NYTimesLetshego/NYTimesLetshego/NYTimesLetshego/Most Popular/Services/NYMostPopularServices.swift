//
//  NYMostPopularServices.swift
//  NYTimesLetshego
//
//  Created by Gabriel Masabata on 9/13/21.
//  Copyright © 2021 Gabriel Masabata. All rights reserved.
//


import UIKit
import Alamofire

let MostPopularSection = "viewed/7.json"

class NYMostPopularServices: NYBaseService {
  func startService(parameters: [String: Any]?, completion: @escaping NetworkResultClosure) {
    let request = NYTnetworkRequest(withMethod: .get,
                                   Path: MostPopularSection,
                                   BodyParameters: parameters,
                                   Headers: [:],
                                   Encoding: URLEncoding.default)
    NYNetworkClient.startRequest(requestConfiguration: request, withMappingClass: NYNews()) { (resutl, error) in
      completion(resutl,error)
    }
  }
}
