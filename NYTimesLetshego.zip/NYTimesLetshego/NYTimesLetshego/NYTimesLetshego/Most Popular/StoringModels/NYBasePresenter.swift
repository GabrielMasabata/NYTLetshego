//
//  NYBaseService.swift
//  NYTimesLetshego
//
//  Created by Gabriel Masabata on 9/13/21.
//  Copyright © 2021 Gabriel Masabata. All rights reserved.
//


import UIKit

protocol NYBasePresenter: class {
  associatedtype T
  var view: T? {get set}
  func attach(this view: T)
  func detach(this view: T)
}

extension NYBasePresenter {
  func attach(this view: T) {
    self.view = view
  }
  func detach(this view: T) {
    self.view = nil
  }
}



