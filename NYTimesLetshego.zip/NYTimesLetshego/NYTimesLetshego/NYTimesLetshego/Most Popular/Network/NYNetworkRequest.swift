//
//  NYTnetworkRequest.swift
//  NYTimes
//
//  Created by Gabriel Masabata on 9/13/21.
//  Copyright © 2021 Gabriel Masabata. All rights reserved.
//

import Alamofire

let APIKeys = "AJAaeJDIHHGYMT131fs0N5vWG1PEk4rp"
enum ServerAddress: String {
  case staging = "http://api.nytimes.com/svc/mostpopular/v2/"
  case quality = " "
  case production  = "  "
}

let NYTserverAddress: ServerAddress = .staging

class NYTnetworkRequest: NSObject {
  
  var baseURL: String {
    return NYTserverAddress.rawValue
  }
  var completeURL: String {
    return self.baseURL + self.path
  }
  
  var requestMethod: HTTPMethod
  var path: String!
  var parameters: [String : Any]
  var headers: [String : String]?
  var modelClass: AnyObject?
  var encoding: ParameterEncoding
  
  init(withMethod Method: HTTPMethod,
       Path path: String,
       BodyParameters parameters: [String : Any]?,
       Headers headers: [String: String]?,
       Encoding encoding: ParameterEncoding) {
    self.path = path
    
    self.parameters = parameters ?? [:]
    self.parameters["api-key"] = APIKeys
    
    self.headers = headers
    self.requestMethod = Method
    self.encoding = encoding
  }
}
