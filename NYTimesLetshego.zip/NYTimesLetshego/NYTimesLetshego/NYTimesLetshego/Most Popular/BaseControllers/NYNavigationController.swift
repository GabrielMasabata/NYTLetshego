//
//  NYNavigationController.swift
//  NYTimesLetshego
//
//  Created by Gabriel Masabata on 9/13/21.
//  Copyright © 2021 Gabriel Masabata. All rights reserved.
//


import UIKit

class NYTNavigationController: UINavigationController {
    
  override func viewDidLoad() {
    super.viewDidLoad()
    
    
  }
  
  override var prefersStatusBarHidden: Bool {
    return false
  }
  
  override var preferredStatusBarStyle: UIStatusBarStyle {
    return UIStatusBarStyle.lightContent
  }
}
